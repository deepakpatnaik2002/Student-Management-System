const firebaseConfig = {
    apiKey: "AIzaSyBmRb0aKxPiB7EV2LQYb7U5SjEyfUMr-ig",
    authDomain: "smsproject-ecd2d.firebaseapp.com",
    projectId: "smsproject-ecd2d",
    storageBucket: "smsproject-ecd2d.appspot.com",
    messagingSenderId: "263965204952",
    appId: "1:263965204952:web:8f4ee00d7db469338092ad",
    measurementId: "G-SED0D8TV4G"
    };

firebase.initializeApp(firebaseConfig);
var db=firebase.firestore();

var rno=document.getElementById("rnoValue");
var year=document.getElementById("yearValue");
var semester=document.getElementById("semesterValue");
var  cgp=document.getElementById("cgpValue");
document.getElementById("sub1").addEventListener('click',register);
document.getElementById("sub2").addEventListener('click',get);



function register(e){
    e.preventDefault();
    if(rno.value==""||year.value==""||semester.value==""||cgp.value==""){
        alert("Please fill all the fields");
        return;
    }
    db.collection('grades').add({
        Rno:rno.value,
        Year:year.value,
        Semester:semester.value,
        Cgp:cgp.value
    })
    .then(function(docRef) {
        console.log("Document written with ID: ", docRef.id);
        alert('Record Added Successfully');
    })
    .catch(function(error) {
        console.error("Error adding document: ", error);
    });
    
}