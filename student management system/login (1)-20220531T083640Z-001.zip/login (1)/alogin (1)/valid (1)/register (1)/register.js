const firebaseConfig = {
    apiKey: "AIzaSyBmRb0aKxPiB7EV2LQYb7U5SjEyfUMr-ig",
    authDomain: "smsproject-ecd2d.firebaseapp.com",
    projectId: "smsproject-ecd2d",
    storageBucket: "smsproject-ecd2d.appspot.com",
    messagingSenderId: "263965204952",
    appId: "1:263965204952:web:8f4ee00d7db469338092ad",
    measurementId: "G-SED0D8TV4G"
    };

firebase.initializeApp(firebaseConfig);
var db=firebase.firestore();

var rno=document.getElementById("rnoValue");
var branch=document.getElementById("branchValue");
var course=document.getElementById("courseValue");
var fname=document.getElementById("fnameValue");
var lname=document.getElementById("lnameValue");
var faname=document.getElementById("fanameValue");
var maname=document.getElementById("manameValue");
var email=document.getElementById("emailValue");
var phone=document.getElementById("phoneValue");
var address=document.getElementById("addressValue");
var dob=document.getElementById("dobValue");
var doj=document.getElementById("dojValue");
document.getElementById("sub").addEventListener('click',register);
function register(e){
    e.preventDefault();
    if(rno.value===''||branch.value===''||fname.value===''||lname.value===''||faname.value===''||maname.value===''||email.value===''||phone.value===''||address.value===''||dob.value===''||doj.value===''){
        alert("Please fill all the fields");
        return;
    }
    db.collection('register').add({
        Rno:rno.value,
        Branch:branch.value,
        First_Name:fname.value,
        Last_Name:lname.value,
        Father_Name:faname.value,
        Mother_Name:maname.value,
        Email:email.value,
        Phone:phone.value,
        Address:address.value,
        DOB:dob.value,
        DOJ:doj.value
    })
    .then(function(docRef) {
        console.log("Document written with ID: ", docRef.id);
        alert('Record Added Successfully');
    })
    .catch(function(error) {
        console.error("Error adding document: ", error);
    }
    );
}